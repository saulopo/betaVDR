# beta VDR
A MATLAB implementation of the beta-VDR fourth-order finite-difference method 

Accompanied the manuscript by Oliveira & Pham (2021), submitted to Computers & Geosciences.

The Program has been tested in MATLAB 2017a and Octave v. 4.2.2.
         
## Instructions:

1. Make sure you have all the files provided in this package in the same folder:

* Example.m    : Main script  
* LoadXYZ.m    : Script to load the data
* taper2d.m    : Auxiliary function for 2D grid expansion   
* betaVDR.m    : Beta-VDR fourth-order finite-difference method 
* TN4th.m      : Fourth-order Tran-Nguyen method
* BDF.m        : First-order backward finite difference method
* dzFreq.m     : Vertical derivative in frequency domain
* input.dat    : Example of input data
* ColorMap.mat : colormap used in the manuscript
* license.txt  : License term
* readme.txt   : This file

2. If you prefer to use your own data, please save it as an ASCII file with 3 columns with the following data per column:

* Column 1: x coordinates 
* Column 2: y coordinates 
* Column 3: anomaly

If necessary, update the file name on Line 15 of file Example.m:

[x,y,Mo]=LoadXYZ('input.dat');

3. Run the program 'Example'

5. The program will generate, using the four methods above (betaVDR, TN4th, dzBDF, and dzder), the following three plots:

* Vertical derivative
* TDX (Cooper & Cowan, Comp & Geosc, 2006)
* ED (Pham, J Afr Eath Sci, 2021)
